D:\project\JS_Bank_Collapse\util\model\multi\test\result.json 0.5 0.5 0.16 0.48 0.36 0.16 0.48 0.36
